import click
import task_lib


@click.group()
def cli():
    """TaskHub CLI на Click."""
    pass


@cli.command()
@click.argument("text", nargs=-1, required=True)
def add(text):
    """Додає нове завдання."""
    task_lib.add_task(list(text))


@cli.command()
def show():
    """Показує всі завдання."""
    task_lib.show_tasks([])


@cli.command()
@click.argument("number")
@click.argument("text", nargs=-1, required=True)
def edit(number, text):
    """Змінює текст завдання."""
    task_lib.edit_task([number] + list(text))


@cli.command()
@click.argument("number")
def done(number):
    """Позначає завдання виконаним."""
    task_lib.done_task([number])


@cli.command()
@click.argument("number")
def delete(number):
    """Видаляє завдання."""
    task_lib.delete_task([number])


@cli.command()
def count():
    """Рахує всі завдання."""
    task_lib.count_tasks([])


@cli.command()
def progress():
    """Показує прогрес."""
    task_lib.show_progress([])


@cli.command()
def random():
    """Вибирає випадкове завдання."""
    task_lib.random_task([])


if __name__ == "__main__":
    cli()
import questionary
import task_lib


def main():
    while True:
        action = questionary.select(
            "Оберіть дію:",
            choices=[
                "Додати завдання (add)",
                "Показати всі (show)",
                "Редагувати (edit)",
                "Виконано (done)",
                "Видалити (delete)",
                "Статистика (count / progress)",
                "Випадкове завдання (random)",
                "Вихід",
            ],
        ).ask()

        if action is None or action == "Вихід":
            print("Бувайте!")
            break

        if "add" in action:
            text = questionary.text("Введіть текст завдання:").ask()
            if text:
                task_lib.add_task([text])

        elif "show" in action:
            task_lib.show_tasks([])

        elif "edit" in action:
            task_lib.show_tasks([])
            num = questionary.text("Номер завдання для редагування:").ask()
            new_text = questionary.text("Новий текст:").ask()
            if num and new_text:
                task_lib.edit_task([num, new_text])

        elif "done" in action:
            task_lib.show_tasks([])
            num = questionary.text("Номер виконаного завдання:").ask()
            if num:
                task_lib.done_task([num])

        elif "delete" in action:
            task_lib.show_tasks([])
            num = questionary.text("Номер завдання для видалення:").ask()
            if num:
                task_lib.delete_task([num])

        elif "count" in action:
            task_lib.count_tasks([])
            task_lib.show_progress([])

        elif "random" in action:
            task_lib.random_task([])

        print("-" * 30)


if __name__ == "__main__":
    main()
import json
import os

FOLDER = "data-storage"
FILEPATH = os.path.join(FOLDER, "my_tasks.json")


def load_tasks():
    """Зчитує завдання з файлу."""
    if not os.path.exists(FILEPATH):
        return []
    with open(FILEPATH, "r", encoding="utf-8") as file:
        return json.load(file)


def save_tasks(tasks):
    """Зберігає завдання у файлі."""
    os.makedirs(FOLDER, exist_ok=True)
    with open(FILEPATH, "w", encoding="utf-8") as file:
        json.dump(tasks, file, ensure_ascii=False, indent=4)


def get_valid_index(number_text, tasks):
    """Перевіряє номер і повертає індекс у списку (або None)."""
    if not number_text.isdigit():
        print("Помилка: номер має бути цілим числом.")
        return None

    task_num = int(number_text)
    if task_num < 1 or task_num > len(tasks):
        print("Помилка: завдання з таким номером немає.")
        return None

    return task_num - 1
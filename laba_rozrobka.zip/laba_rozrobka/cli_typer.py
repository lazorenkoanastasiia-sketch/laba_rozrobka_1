import typer
import task_lib

app = typer.Typer(help="TaskHub CLI на Typer")


@app.command()
def add(text: list[str]):
    """Додає нове завдання."""
    task_lib.add_task(text)


@app.command()
def show():
    """Показує всі завдання."""
    task_lib.show_tasks([])


@app.command()
def edit(number: str, text: list[str]):
    """Змінює текст завдання."""
    task_lib.edit_task([number] + text)


@app.command()
def done(number: str):
    """Позначає завдання виконаним."""
    task_lib.done_task([number])


@app.command()
def delete(number: str):
    """Видаляє завдання."""
    task_lib.delete_task([number])


@app.command()
def count():
    """Рахує всі завдання."""
    task_lib.count_tasks([])


@app.command()
def progress():
    """Показує прогрес."""
    task_lib.show_progress([])


@app.command()
def random():
    """Вибирає випадкове завдання."""
    task_lib.random_task([])


if __name__ == "__main__":
    app()

import argparse
import task_lib


def main():
    parser = argparse.ArgumentParser(description="TaskHub CLI на argparse")
    subparsers = parser.add_subparsers(dest="command", required=True, help="Доступні команди")

    # add
    add_p = subparsers.add_parser("add", help="Додати нове завдання")
    add_p.add_argument("text", nargs="+", help="Текст завдання")

    # show
    subparsers.add_parser("show", help="Показати всі завдання")

    # edit
    edit_p = subparsers.add_parser("edit", help="Змінити текст завдання")
    edit_p.add_argument("number", help="Номер завдання")
    edit_p.add_argument("text", nargs="+", help="Новий текст")

    # done
    done_p = subparsers.add_parser("done", help="Позначити виконаним")
    done_p.add_argument("number", help="Номер завдання")

    # delete
    del_p = subparsers.add_parser("delete", help="Видалити завдання")
    del_p.add_argument("number", help="Номер завдання")

    # аналітика
    subparsers.add_parser("count", help="Порахувати всі завдання")
    subparsers.add_parser("progress", help="Показати прогрес")
    subparsers.add_parser("random", help="Випадкове невиконане завдання")

    args = parser.parse_args()

    # Викликаємо функції з task_lib, передаючи аргументи у вигляді списку, як вони очікують
    if args.command == "add":
        task_lib.add_task(args.text)
    elif args.command == "edit":
        task_lib.edit_task([args.number] + args.text)
    elif args.command in ("done", "delete"):
        task_lib.COMMANDS[args.command]([args.number])
    else:
        task_lib.COMMANDS[args.command]([])


if __name__ == "__main__":
    main()